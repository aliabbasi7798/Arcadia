class Tiger extends NormalMonster{
    public Tiger(){
        attackPoint=3000;
        healthPoint=3000;
    }
}
