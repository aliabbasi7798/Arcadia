class Game
{
    Team own=new Team();
    Team enemy=new Team();

}