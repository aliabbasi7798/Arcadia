class ElvenSorcerss extends SpellCaster{
    public ElvenSorcerss(){
        this.type="12";
        this.name="Elven Sorceress";
        this.attackPoint=1000;
        this.healthPoint=1000;
        this.magicPoint=7;
        this.nimble=true;
        this.defender=false;
    }

    public void spell(/*argoman is a team*/){
        /* ******************************* */

    }
}
