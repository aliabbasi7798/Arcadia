class NobleElf extends General{

    public NobleElf(){
        this.type="13";
        this.name="Noble Elf";
        this.attackPoint=2400;
        this.healthPoint=2000;
        this.magicPoint=9;
        this.nimble=false;
        this.defender=false;
    }

    public void battleCry(/* team */){

    }

    public void will(/* team */){

    }
}
