class ContinuousSpell extends SpellCard{

}
