class SpellCard extends Card{
    protected boolean spellFeild=false;





}
