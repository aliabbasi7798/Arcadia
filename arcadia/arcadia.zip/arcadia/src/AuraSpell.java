class AuraSpell extends SpellCard{

}
