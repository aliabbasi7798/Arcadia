class James extends NormalMonster{
    public James(){
        attackPoint=1000;
        healthPoint=1000;
    }
}
