class SpellCaster extends MonsterCard{
    public void spell(){

    }
}
