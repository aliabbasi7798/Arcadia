class NormalMonster extends MonsterCard{

}
