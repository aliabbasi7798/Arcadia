class InstantSpell extends SpellCard{
    public void action(){

    }
}
